import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { SecurityChecklist } from './components/SecurityChecklist';
import { GeminiAdvisor } from './components/GeminiAdvisor';
import { NetworkVisualizer } from './components/NetworkVisualizer';
import { PermissionAuditor } from './components/PermissionAuditor';
import { ChecklistItem, SecurityLevel } from './types';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

const INITIAL_ITEMS: ChecklistItem[] = [
  // Technical
  { id: '1', category: 'Technical', title: 'Monitor Outbound Traffic', description: 'Use tools like Little Snitch or GlassWire to check for unknown apps connecting to the internet.', isCompleted: false, severity: 'High' },
  { id: '2', category: 'Technical', title: 'Audit Running Processes', description: 'Check Activity Monitor or Task Manager for suspicious background processes consuming CPU/Network.', isCompleted: false, severity: 'High' },
  { id: '3', category: 'Technical', title: 'Scan for Spyware', description: 'Run a deep scan using reputable anti-malware software designed to detect keyloggers.', isCompleted: false, severity: 'Medium' },
  
  // Physical
  { id: '4', category: 'Physical', title: 'Scan for RF Signals', description: 'Use an RF detector to find devices transmitting data (cameras, bugs).', isCompleted: false, severity: 'High' },
  { id: '5', category: 'Physical', title: 'Lens Reflection Check', description: 'Use a flashlight or phone camera flash to look for lens reflections in smoke detectors, vents, or decor.', isCompleted: false, severity: 'Medium' },
  { id: '6', category: 'Physical', title: 'Check USB Ports', description: 'Inspect computer ports for unfamiliar dongles or "juice jacking" devices.', isCompleted: false, severity: 'Low' },

  // Privacy
  { id: '7', category: 'Privacy', title: 'Review App Permissions', description: 'Revoke camera/mic access for apps that do not strictly need it.', isCompleted: false, severity: 'High' },
  { id: '8', category: 'Privacy', title: 'Encrypt Internet Traffic', description: 'Use a trusted VPN to prevent local network snooping.', isCompleted: false, severity: 'Medium' },
  { id: '9', category: 'Privacy', title: 'Physical Webcam Cover', description: 'Apply a sticker or slide cover to cameras when not in use.', isCompleted: false, severity: 'Medium' },

  // Behavioral
  { id: '10', category: 'Behavioral', title: 'Analyze Targeted Ads', description: 'Note if ads reference private conversations held near devices.', isCompleted: false, severity: 'Low' },
  { id: '11', category: 'Behavioral', title: 'Check Login Activity', description: 'Review "Recent Devices" in account settings for unknown locations.', isCompleted: false, severity: 'High' },
];

function App() {
  const [items, setItems] = useState<ChecklistItem[]>(INITIAL_ITEMS);

  const toggleItem = (id: string) => {
    setItems(prev => prev.map(item => 
      item.id === id ? { ...item, isCompleted: !item.isCompleted } : item
    ));
  };

  const progress = useMemo(() => {
    const completed = items.filter(i => i.isCompleted).length;
    return Math.round((completed / items.length) * 100);
  }, [items]);

  const securityLevel = useMemo(() => {
    if (progress < 30) return SecurityLevel.LOW;
    if (progress < 70) return SecurityLevel.MEDIUM;
    if (progress < 100) return SecurityLevel.HIGH;
    return SecurityLevel.SECURE;
  }, [progress]);

  const chartData = [
    { name: 'Completed', value: progress },
    { name: 'Remaining', value: 100 - progress },
  ];

  const getSecurityColor = (level: SecurityLevel) => {
    switch(level) {
      case SecurityLevel.LOW: return '#ef4444';
      case SecurityLevel.MEDIUM: return '#f59e0b';
      case SecurityLevel.HIGH: return '#34d399';
      case SecurityLevel.SECURE: return '#10b981';
    }
  };

  return (
    <div className="min-h-screen bg-sentinel-900 text-slate-200 font-sans selection:bg-emerald-500/30">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Progress & Visuals */}
          <div className="lg:col-span-4 space-y-8">
            {/* Score Card */}
            <div className="bg-sentinel-800 rounded-2xl border border-sentinel-700 p-6 flex flex-col items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 to-transparent" />
              <div className="relative z-10 w-48 h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={chartData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      startAngle={90}
                      endAngle={-270}
                      dataKey="value"
                      stroke="none"
                    >
                      <Cell fill={getSecurityColor(securityLevel)} />
                      <Cell fill="#1e293b" />
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-4xl font-bold font-mono text-white">{progress}%</span>
                  <span className="text-xs text-slate-400 uppercase tracking-widest mt-1">Protected</span>
                </div>
              </div>
              <div className="mt-4 text-center">
                <h2 className="text-xl font-bold text-white mb-1">Status: <span style={{ color: getSecurityColor(securityLevel) }}>{securityLevel}</span></h2>
                <p className="text-sm text-slate-400">Complete the checklist to improve your privacy score.</p>
              </div>
            </div>

            <PermissionAuditor />
            <NetworkVisualizer />
          </div>

          {/* Middle Column: Checklist */}
          <div className="lg:col-span-5">
            <div className="bg-sentinel-800/50 rounded-2xl p-1 mb-6 border border-sentinel-700">
              <div className="px-6 py-4">
                <h2 className="text-2xl font-bold text-white mb-2">Detection Protocol</h2>
                <p className="text-slate-400">Follow these steps to audit your environment for unauthorized AI surveillance and data collection.</p>
              </div>
            </div>
            <SecurityChecklist items={items} onToggle={toggleItem} />
          </div>

          {/* Right Column: AI Advisor */}
          <div className="lg:col-span-3">
             <div className="sticky top-24">
                <GeminiAdvisor />
                <div className="mt-6 p-4 bg-indigo-900/20 border border-indigo-500/20 rounded-xl">
                  <h4 className="text-indigo-400 font-semibold mb-2 text-sm uppercase tracking-wider">Why use this?</h4>
                  <p className="text-sm text-indigo-200/80 leading-relaxed">
                    AI surveillance isn't just cameras; it's algorithmic tracking of your behavior. This dashboard helps you reduce your digital footprint and identify physical bugs.
                  </p>
                </div>
             </div>
          </div>

        </div>
      </main>
    </div>
  );
}

export default App;