export interface ChecklistItem {
  id: string;
  category: 'Technical' | 'Physical' | 'Behavioral' | 'Privacy';
  title: string;
  description: string;
  isCompleted: boolean;
  severity: 'High' | 'Medium' | 'Low';
}

export interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export enum SecurityLevel {
  LOW = 'Low',
  MEDIUM = 'Medium',
  HIGH = 'High',
  SECURE = 'Secure'
}