import React from 'react';
import { ChecklistItem } from '../types';
import { CheckCircle2, Circle, AlertTriangle, Shield, Eye } from 'lucide-react';

interface SecurityChecklistProps {
  items: ChecklistItem[];
  onToggle: (id: string) => void;
}

const ChecklistGroup: React.FC<{ 
  title: string; 
  items: ChecklistItem[]; 
  onToggle: (id: string) => void;
  icon: React.ReactNode;
}> = ({ title, items, onToggle, icon }) => {
  if (items.length === 0) return null;

  return (
    <div className="mb-8">
      <div className="flex items-center gap-3 mb-4 border-b border-sentinel-800 pb-2">
        {icon}
        <h3 className="text-lg font-semibold text-white">{title}</h3>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2">
        {items.map((item) => (
          <div 
            key={item.id}
            onClick={() => onToggle(item.id)}
            className={`
              relative p-4 rounded-xl border transition-all duration-300 cursor-pointer group
              ${item.isCompleted 
                ? 'bg-emerald-900/10 border-emerald-500/30 hover:bg-emerald-900/20' 
                : 'bg-sentinel-800 border-sentinel-700 hover:border-slate-500'
              }
            `}
          >
            <div className="flex items-start gap-4">
              <div className={`mt-1 transition-colors duration-300 ${item.isCompleted ? 'text-emerald-500' : 'text-slate-500 group-hover:text-slate-300'}`}>
                {item.isCompleted ? <CheckCircle2 className="w-6 h-6" /> : <Circle className="w-6 h-6" />}
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start mb-1">
                  <h4 className={`font-medium transition-colors ${item.isCompleted ? 'text-slate-200' : 'text-white'}`}>
                    {item.title}
                  </h4>
                  <span className={`
                    text-xs px-2 py-0.5 rounded-full font-mono uppercase
                    ${item.severity === 'High' ? 'bg-red-500/20 text-red-400' : 
                      item.severity === 'Medium' ? 'bg-amber-500/20 text-amber-400' : 
                      'bg-blue-500/20 text-blue-400'}
                  `}>
                    {item.severity}
                  </span>
                </div>
                <p className="text-sm text-slate-400">{item.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export const SecurityChecklist: React.FC<SecurityChecklistProps> = ({ items, onToggle }) => {
  const technicalItems = items.filter(i => i.category === 'Technical');
  const physicalItems = items.filter(i => i.category === 'Physical');
  const privacyItems = items.filter(i => i.category === 'Privacy');
  const behavioralItems = items.filter(i => i.category === 'Behavioral');

  return (
    <div className="bg-sentinel-900 rounded-2xl">
      <ChecklistGroup 
        title="Technical & Network Analysis" 
        items={technicalItems} 
        onToggle={onToggle} 
        icon={<AlertTriangle className="w-5 h-5 text-amber-400" />}
      />
      <ChecklistGroup 
        title="Physical Inspection" 
        items={physicalItems} 
        onToggle={onToggle}
        icon={<Eye className="w-5 h-5 text-blue-400" />}
      />
      <ChecklistGroup 
        title="Privacy & Digital Hygiene" 
        items={privacyItems} 
        onToggle={onToggle}
        icon={<Shield className="w-5 h-5 text-emerald-400" />}
      />
      <ChecklistGroup 
        title="Behavioral Indicators" 
        items={behavioralItems} 
        onToggle={onToggle}
        icon={<Circle className="w-5 h-5 text-purple-400" />}
      />
    </div>
  );
};