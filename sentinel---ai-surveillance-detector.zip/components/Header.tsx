import React from 'react';
import { ShieldCheck, Eye, Lock, Minus, Square, X } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-50 bg-sentinel-900 border-b border-sentinel-800 shadow-md">
      <div className="flex justify-between items-center h-12 pl-4">
        {/* App Identity */}
        <div className="flex items-center gap-3">
          <div className="p-1 bg-emerald-500/10 rounded-lg">
            <ShieldCheck className="w-5 h-5 text-emerald-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <h1 className="text-sm font-bold text-white tracking-wide">SENTINEL</h1>
            <span className="text-[10px] text-slate-500 uppercase tracking-wider font-medium">v2.1.0 • Windows</span>
          </div>
        </div>

        {/* Windows Title Bar Controls */}
        <div className="flex h-full">
           <div className="hidden md:flex items-center gap-6 mr-6 border-r border-sentinel-800 pr-6 h-full">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <Eye className="w-3 h-3" />
              <span>Background Monitoring</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-emerald-400">
              <Lock className="w-3 h-3" />
              <span>Firewall Active</span>
            </div>
          </div>
          
          <button className="w-12 h-full flex items-center justify-center text-slate-400 hover:bg-sentinel-800 transition-colors">
            <Minus className="w-4 h-4" />
          </button>
          <button className="w-12 h-full flex items-center justify-center text-slate-400 hover:bg-sentinel-800 transition-colors">
            <Square className="w-3 h-3" />
          </button>
          <button className="w-12 h-full flex items-center justify-center text-slate-400 hover:bg-red-500 hover:text-white transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};