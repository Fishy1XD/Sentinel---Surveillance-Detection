import React, { useState, useEffect, useRef } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Activity, ArrowUpRight, ArrowDownLeft, ShieldCheck, ShieldAlert, Terminal, History, Bell, BellOff, X, Check, Shield, Zap, ScanEye, Ban, Lock, Settings2, PlayCircle, Plus, Trash2, Search, AlertTriangle, BrainCircuit, ChevronDown, Cpu } from 'lucide-react';

interface DataPoint {
  time: number;
  upload: number;
  download: number;
  type: string;
}

interface ThreatLogEntry {
  id: string;
  time: string;
  process: string;
  threat: string;
  type: string;
  action: 'Blocked' | 'Detected' | 'Allowed';
}

const THREAT_SIGNATURES = [
  { name: 'Mindgard AI', process: 'mindgard_agent.exe', type: 'AI Red Teaming' },
  { name: 'WormGPT', process: 'python.exe', type: 'Malicious AI Bot' },
  { name: 'Cybereason', process: 'cr_service.exe', type: 'Behavioral Analytics' },
  { name: 'Burp Suite', process: 'javaw.exe', type: 'Vuln Scanner' },
  { name: 'Metasploit', process: 'ruby.exe', type: 'Exploit Framework' },
  { name: 'Kali Linux', process: 'wsl.exe', type: 'Offensive Toolset' },
  { name: 'Recon-NG', process: 'python3.exe', type: 'OSINT Gatherer' },
  { name: 'SQLMap', process: 'sqlmap_proc.exe', type: 'SQL Injection' },
  { name: 'Cobalt Strike', process: 'rundll32.exe', type: 'C2 Beacon' },
  { name: 'Wireshark', process: 'wireshark.exe', type: 'Packet Sniffer' },
  { name: 'Unknown Process', process: 'svchost.exe (PID: 9999)', type: 'Suspicious Activity' }
];

const BENIGN_PROCESSES = [
  'chrome.exe', 'firefox.exe', 'spotify.exe', 'outlook.exe', 'teams.exe', 'explorer.exe'
];

const generateInitialData = (): DataPoint[] => {
  return Array.from({ length: 40 }, (_, i) => ({
    time: i,
    upload: 5,
    download: 5,
    type: 'Idle'
  }));
};

const getTimestamp = () => {
  const now = new Date();
  const h = now.getHours().toString().padStart(2, '0');
  const m = now.getMinutes().toString().padStart(2, '0');
  const s = now.getSeconds().toString().padStart(2, '0');
  const ms = now.getMilliseconds().toString().padStart(3, '0');
  return `${h}:${m}:${s}.${ms}`;
};

export const NetworkVisualizer: React.FC = () => {
  // Main State
  const [data, setData] = useState<DataPoint[]>(generateInitialData());
  const [firewallMode, setFirewallMode] = useState<'auto' | 'notify' | 'off'>('auto'); // Default to AUTO for max security
  const [pendingThreat, setPendingThreat] = useState<{name: string, process: string, type: string} | null>(null);
  const [view, setView] = useState<'monitor' | 'rules'>('monitor');
  const [showModeDropdown, setShowModeDropdown] = useState(false);
  
  // User Configuration
  const [uploadThreshold, setUploadThreshold] = useState(250);
  const [threatLogs, setThreatLogs] = useState<ThreatLogEntry[]>([]);
  const [customRuleInput, setCustomRuleInput] = useState('');
  
  // Default Blocklist - Comprehensive for privacy
  const [blockedApps, setBlockedApps] = useState<Set<string>>(new Set([
    'Mindgard AI', 'WormGPT', 'Cobalt Strike', 'Metasploit', 'Kali Linux', 'Burp Suite',
    'python.exe', 'powershell.exe' 
  ]));

  // Simulation Refs & Heuristics
  const tickRef = useRef(0);
  const processedThreatsRef = useRef<Set<number>>(new Set());
  const sustainedHighTrafficRef = useRef(0);
  const unusualRatioRef = useRef(0);

  // Request Notification Permissions on Mount
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }, []);

  const sendSystemNotification = (title: string, body: string) => {
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification(title, {
        body,
        icon: 'https://cdn-icons-png.flaticon.com/512/9630/9630249.png',
        silent: false
      });
    }
  };

  const toggleAppBlock = (appName: string) => {
    setBlockedApps(prev => {
      const next = new Set(prev);
      if (next.has(appName)) {
        next.delete(appName);
      } else {
        next.add(appName);
      }
      return next;
    });
  };

  const addCustomRule = () => {
    if (customRuleInput.trim()) {
      setBlockedApps(prev => new Set(prev).add(customRuleInput.trim()));
      setCustomRuleInput('');
    }
  };

  const handleThreatDecision = (allow: boolean) => {
    if (pendingThreat) {
      const newLog: ThreatLogEntry = {
        id: Date.now().toString(),
        time: getTimestamp(),
        process: pendingThreat.process,
        threat: pendingThreat.name,
        type: pendingThreat.type,
        action: allow ? 'Allowed' : 'Blocked'
      };
      setThreatLogs(prev => [newLog, ...prev].slice(0, 50));
      
      // If manually blocked, add to blocklist
      if (!allow) {
        toggleAppBlock(pendingThreat.name);
        toggleAppBlock(pendingThreat.process); // Also block process name
      }

      setPendingThreat(null);
    }
  };

  // Main Traffic Simulation Loop
  useEffect(() => {
    const interval = setInterval(() => {
      // Pause updates if user needs to make a decision in notify mode
      if (pendingThreat) return;

      tickRef.current += 1;
      
      setData(prev => {
        const lastData = prev[prev.length - 1];
        
        // --- Heuristic Analysis ---
        // 1. Detect Sustained High Upload (Data Exfiltration)
        if (lastData.upload > 200) sustainedHighTrafficRef.current += 1;
        else sustainedHighTrafficRef.current = 0;

        // 2. Detect Anomalous Ratio (C2 Heartbeat)
        if (lastData.upload > 80 && lastData.upload > lastData.download * 5) unusualRatioRef.current += 1;
        else unusualRatioRef.current = 0;

        // --- Threat Determination ---
        let potentialThreat = null;

        // Priority 1: Heuristic Detection
        if (sustainedHighTrafficRef.current >= 5) {
          potentialThreat = { name: 'Hidden Exfiltration', process: 'background_task_host.exe', type: 'Data Theft (Heuristic)' };
          sustainedHighTrafficRef.current = 0;
        } else if (unusualRatioRef.current >= 4) {
          potentialThreat = { name: 'C2 Heartbeat', process: 'powershell.exe', type: 'Botnet Activity (Heuristic)' };
          unusualRatioRef.current = 0;
        } 
        // Priority 2: Random Signature Match
        else if (Math.random() > 0.98) {
           potentialThreat = THREAT_SIGNATURES[Math.floor(Math.random() * THREAT_SIGNATURES.length)];
        }

        // --- Data Generation ---
        let newUpload = 0;
        let newDownload = 0;
        let newType = 'Idle';
        
        if (potentialThreat) {
           const threatId = tickRef.current;
           newType = potentialThreat.type;
           const isBlacklisted = blockedApps.has(potentialThreat.name) || blockedApps.has(potentialThreat.process);

           // LOGIC: Block Rule > Auto Block > Notify > Off
           
           if (firewallMode === 'off') {
             newUpload = Math.floor(Math.random() * 600) + 300; 
             newDownload = Math.floor(Math.random() * 100) + 20;
             if (isBlacklisted && Math.random() > 0.5) {
               // Passive log
             }
           } else if (isBlacklisted) {
             // 1. Blocked by Rule
             newUpload = 0;
             newDownload = 0;
             newType = 'Blocked (Rule)';
             
             const lastLog = threatLogs[0];
             if (!lastLog || lastLog.threat !== potentialThreat.name || (Date.now() - parseInt(lastLog.id) > 2000)) {
                setTimeout(() => {
                   setThreatLogs(prevLogs => [{
                      id: Date.now().toString(),
                      time: getTimestamp(),
                      process: potentialThreat!.process,
                      threat: potentialThreat!.name,
                      type: potentialThreat!.type,
                      action: 'Blocked' as const
                   }, ...prevLogs].slice(0, 50));
                }, 0);
             }
           } else if (firewallMode === 'auto') {
             // 2. Auto Block (Default Security Posture)
             newUpload = 0; 
             newDownload = 0;
             newType = 'Blocked (Auto)';
             
             const lastLog = threatLogs[0];
             if (!lastLog || lastLog.threat !== potentialThreat.name || (Date.now() - parseInt(lastLog.id) > 2000)) {
                setTimeout(() => {
                   setThreatLogs(prevLogs => [{
                      id: Date.now().toString(),
                      time: getTimestamp(),
                      process: potentialThreat!.process,
                      threat: potentialThreat!.name,
                      type: potentialThreat!.type,
                      action: 'Blocked' as const
                   }, ...prevLogs].slice(0, 50));
                }, 0);
             }

           } else if (firewallMode === 'notify') {
             // 3. Notify User
             newUpload = 0;
             newDownload = 0;
             newType = 'Suspended';

             setTimeout(() => {
                if (!processedThreatsRef.current.has(threatId)) {
                   processedThreatsRef.current.add(threatId);
                   setPendingThreat({ name: potentialThreat!.name, process: potentialThreat!.process, type: potentialThreat!.type });
                   sendSystemNotification(
                     "Sentinel Firewall Alert", 
                     `Blocked: ${potentialThreat!.process} (${potentialThreat!.name})`
                   );
                }
             }, 0);
           }
        } else {
           // Normal Traffic
           const isStreaming = Math.sin(tickRef.current * 0.1) > 0.4;
           if (isStreaming) {
             newUpload = Math.floor(Math.random() * 40) + 10;
             newDownload = Math.floor(Math.random() * 600) + 300;
             newType = BENIGN_PROCESSES[Math.floor(Math.random() * BENIGN_PROCESSES.length)];
           } else {
             newUpload = Math.floor(Math.random() * 20) + 2;
             newDownload = Math.floor(Math.random() * 30) + 2;
             newType = 'System Idle';
           }
        }

        const newDataPoint = {
          time: prev[prev.length - 1].time + 1,
          upload: newUpload,
          download: newDownload,
          type: newType
        };

        return [...prev.slice(1), newDataPoint];
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [firewallMode, pendingThreat, threatLogs, blockedApps]);

  const currentData = data[data.length - 1];

  const getModeStyles = () => {
    switch (firewallMode) {
      case 'auto': return 'bg-emerald-900/20 border-emerald-500/50 shadow-[0_0_15px_rgba(16,185,129,0.1)]';
      case 'notify': return 'bg-amber-900/20 border-amber-500/50 shadow-[0_0_15px_rgba(245,158,11,0.1)]';
      case 'off': return 'bg-slate-800/50 border-sentinel-700';
    }
  };

  const customBlockedApps = Array.from(blockedApps).filter(app => !THREAT_SIGNATURES.some(t => t.name === app || t.process === app));

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const type = payload[0].payload.type;
      const isDangerous = type !== 'Blocked (Auto)' && type !== 'Blocked (Rule)' && !BENIGN_PROCESSES.includes(type) && type !== 'System Idle';
      return (
        <div className="bg-sentinel-900/95 border border-sentinel-700 p-3 rounded-lg shadow-xl backdrop-blur-md text-xs">
          <p className="text-slate-500 mb-2 font-mono">T-{label}</p>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span className="text-slate-300">Down: {payload[1].value} KB/s</span>
            </div>
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${isDangerous ? 'bg-red-500 animate-pulse' : 'bg-amber-500'}`}></span>
              <span className={isDangerous ? 'text-red-400 font-bold' : 'text-slate-300'}>
                Up: {payload[0].value} KB/s
              </span>
            </div>
            <div className="pt-2 mt-2 border-t border-sentinel-800 text-indigo-400 font-semibold italic flex items-center gap-2">
              <Activity className="w-3 h-3" />
              {type}
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className={`rounded-2xl border p-6 overflow-hidden relative group transition-colors duration-500 ${getModeStyles()}`}>
      
      {/* Alert Modal */}
      {pendingThreat && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-sentinel-900/90 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-sentinel-800 border border-red-500/50 rounded-2xl shadow-2xl p-6 max-w-sm w-full mx-4 relative overflow-hidden ring-1 ring-red-500/20">
             <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-red-500 to-amber-500" />
             <div className="flex items-center gap-3 mb-4">
               <div className="p-3 bg-red-500/10 rounded-full">
                 <ShieldAlert className="w-8 h-8 text-red-500 animate-pulse" />
               </div>
               <div>
                 <h3 className="text-lg font-bold text-white">AI Firewall Alert</h3>
                 <p className="text-xs text-red-400 font-mono uppercase tracking-wide">Suspicious Process Detected</p>
               </div>
             </div>
             
             <div className="bg-sentinel-900/50 rounded-lg p-3 mb-6 border border-sentinel-700 space-y-2">
               <div>
                 <div className="text-[10px] text-slate-500 uppercase tracking-wider">Detection</div>
                 <div className="text-white font-mono font-bold">{pendingThreat.name}</div>
               </div>
               <div>
                 <div className="text-[10px] text-slate-500 uppercase tracking-wider">Process</div>
                 <div className="text-indigo-400 font-mono bg-indigo-500/10 px-2 py-0.5 rounded inline-block">{pendingThreat.process}</div>
               </div>
             </div>

             <div className="grid grid-cols-2 gap-3">
               <button 
                 onClick={() => handleThreatDecision(false)}
                 className="flex items-center justify-center gap-2 py-3 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold transition-colors shadow-lg shadow-red-500/20"
               >
                 <Ban className="w-4 h-4" /> BLOCK
               </button>
               <button 
                 onClick={() => handleThreatDecision(true)}
                 className="flex items-center justify-center gap-2 py-3 rounded-lg bg-sentinel-700 hover:bg-sentinel-600 text-slate-300 font-medium transition-colors"
               >
                 <Check className="w-4 h-4" /> ALLOW
               </button>
             </div>
          </div>
        </div>
      )}

      {/* Header Controls */}
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4 mb-6">
        <div>
          <h3 className="text-lg font-semibold text-white flex items-center gap-2">
            <BrainCircuit className="w-5 h-5 text-indigo-400" />
            Sentinel AI Firewall
            
            {/* Quick Mode Switcher */}
            <div className="relative inline-block ml-2 group">
              <button 
                onClick={() => setShowModeDropdown(!showModeDropdown)}
                className={`flex items-center gap-1 text-xs px-2 py-0.5 rounded uppercase font-bold tracking-wider cursor-pointer hover:opacity-80 transition-opacity ${
                  firewallMode === 'auto' ? 'bg-emerald-500/20 text-emerald-400' :
                  firewallMode === 'notify' ? 'bg-amber-500/20 text-amber-400' :
                  'bg-slate-700 text-slate-400'
                }`}
              >
                {firewallMode}
                <ChevronDown className="w-3 h-3" />
              </button>
              
              <div className="absolute top-full left-0 mt-1 w-24 bg-sentinel-900 border border-sentinel-700 rounded-lg shadow-xl overflow-hidden z-50 flex flex-col py-1 hidden group-hover:flex">
                  {(['auto', 'notify', 'off'] as const).map(mode => (
                    <button
                      key={mode}
                      onClick={() => setFirewallMode(mode)}
                      className={`text-left px-3 py-1.5 text-xs font-medium uppercase hover:bg-white/5 ${firewallMode === mode ? 'text-white' : 'text-slate-400'}`}
                    >
                      {mode}
                    </button>
                  ))}
              </div>
            </div>
          </h3>
          <p className="text-sm text-slate-400 flex items-center gap-2 mt-1">
            <span className={`w-2 h-2 rounded-full ${firewallMode === 'off' ? 'bg-slate-600' : 'bg-emerald-500 animate-pulse'}`}></span>
            {firewallMode === 'off' ? 'Protection disabled' : 'Filtering background processes'}
          </p>
        </div>

        <div className="flex gap-4">
           {/* View Toggle */}
           <div className="flex bg-sentinel-900 p-1 rounded-lg border border-sentinel-700">
             <button
               onClick={() => setView('monitor')}
               className={`px-3 py-1.5 rounded-md text-xs font-bold flex items-center gap-2 transition-all ${view === 'monitor' ? 'bg-sentinel-800 text-white' : 'text-slate-400 hover:text-white'}`}
             >
               <Activity className="w-3 h-3" /> Monitor
             </button>
             <button
               onClick={() => setView('rules')}
               className={`px-3 py-1.5 rounded-md text-xs font-bold flex items-center gap-2 transition-all ${view === 'rules' ? 'bg-sentinel-800 text-white' : 'text-slate-400 hover:text-white'}`}
             >
               <Settings2 className="w-3 h-3" /> Rules
             </button>
           </div>

           {/* Mode Toggle Buttons */}
           <div className="flex items-center gap-1 bg-sentinel-900 p-1 rounded-lg border border-sentinel-700">
             <button
               onClick={() => setFirewallMode('auto')}
               title="Automatically block threats"
               className={`p-2 rounded-md transition-all ${firewallMode === 'auto' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'}`}
             >
               <ShieldCheck className="w-4 h-4" />
             </button>
             <button
               onClick={() => setFirewallMode('notify')}
               title="Ask me what to do"
               className={`p-2 rounded-md transition-all ${firewallMode === 'notify' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'}`}
             >
               <Bell className="w-4 h-4" />
             </button>
             <button
               onClick={() => setFirewallMode('off')}
               title="Turn off firewall"
               className={`p-2 rounded-md transition-all ${firewallMode === 'off' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-white'}`}
             >
               <BellOff className="w-4 h-4" />
             </button>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Panel: Monitor OR Rules */}
        <div className="lg:col-span-2 space-y-6">
          
          {view === 'monitor' ? (
            <>
               {/* Traffic Stats */}
              <div className="grid grid-cols-3 gap-4">
                <div className={`p-3 rounded-xl border transition-all duration-300 ${pendingThreat ? 'bg-red-900/20 border-red-500/50' : 'bg-sentinel-900/50 border-sentinel-700'}`}>
                  <div className="flex items-center gap-2 text-slate-400 mb-1 text-xs uppercase font-mono"><ArrowUpRight className="w-3 h-3" /> Upload</div>
                  <div className="text-xl font-mono text-white">{currentData.upload} <span className="text-xs opacity-50">KB/s</span></div>
                </div>
                <div className="bg-sentinel-900/50 p-3 rounded-xl border border-sentinel-700">
                  <div className="flex items-center gap-2 text-slate-400 mb-1 text-xs uppercase font-mono"><ArrowDownLeft className="w-3 h-3" /> Download</div>
                  <div className="text-xl font-mono text-white">{currentData.download} <span className="text-xs opacity-50">KB/s</span></div>
                </div>
                <div className="bg-sentinel-900/50 p-3 rounded-xl border border-sentinel-700 flex flex-col justify-center">
                  <div className="flex items-center gap-2 text-slate-400 mb-1 text-xs uppercase font-mono"><ScanEye className="w-3 h-3" /> Analysis</div>
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${firewallMode === 'off' ? 'bg-slate-500' : 'bg-indigo-400 animate-pulse'}`} />
                    <span className="text-sm font-medium text-white">{firewallMode === 'off' ? 'Idle' : 'Filtering'}</span>
                  </div>
                </div>
              </div>

              {/* Chart */}
              <div className={`h-[250px] w-full transition-opacity duration-300 ${pendingThreat ? 'opacity-30 blur-[1px]' : 'opacity-100'}`}>
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data}>
                    <defs>
                      <linearGradient id="colorUpload" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={pendingThreat ? "#ef4444" : "#f59e0b"} stopOpacity={0.3}/>
                        <stop offset="95%" stopColor={pendingThreat ? "#ef4444" : "#f59e0b"} stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorDownload" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                    <XAxis dataKey="time" hide />
                    <YAxis hide domain={[0, 800]} />
                    <Tooltip content={<CustomTooltip />} cursor={{ stroke: '#475569', strokeWidth: 1 }} />
                    <Area type="monotone" dataKey="upload" stroke={pendingThreat ? "#ef4444" : "#f59e0b"} fillOpacity={1} fill="url(#colorUpload)" strokeWidth={2} isAnimationActive={false} />
                    <Area type="monotone" dataKey="download" stroke="#10b981" fillOpacity={1} fill="url(#colorDownload)" strokeWidth={2} isAnimationActive={false} />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </>
          ) : (
            <div className="h-[350px] bg-sentinel-900/50 rounded-xl border border-sentinel-700 flex flex-col overflow-hidden">
               {/* Rules View */}
               <div className="p-4 border-b border-sentinel-700 bg-sentinel-900">
                  <h4 className="text-white font-bold flex items-center gap-2"><Lock className="w-4 h-4 text-emerald-400"/> Custom Blocklist Rules</h4>
                  <p className="text-xs text-slate-400 mt-1">Add application names (e.g. `malware.exe`) to block them immediately.</p>
               </div>
               
               {/* Input Area */}
               <div className="p-4 border-b border-sentinel-700 bg-sentinel-800/50">
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                      <input 
                        type="text" 
                        value={customRuleInput}
                        onChange={(e) => setCustomRuleInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && addCustomRule()}
                        placeholder="Enter process name (e.g., 'powershell.exe', 'curl.exe')"
                        className="w-full bg-sentinel-900 border border-sentinel-700 rounded-lg pl-9 pr-4 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                      />
                    </div>
                    <button 
                      onClick={addCustomRule}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-bold flex items-center gap-2 transition-colors"
                    >
                      <Plus className="w-4 h-4" /> Add Rule
                    </button>
                  </div>
               </div>

               <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar">
                  
                  {/* Known Signatures Section */}
                  <div>
                    <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                        <ShieldAlert className="w-3 h-3" /> Known AI Threats
                    </h5>
                    <div className="grid grid-cols-1 gap-2">
                        {THREAT_SIGNATURES.map(sig => {
                            const isBlocked = blockedApps.has(sig.name);
                            return (
                                <div key={sig.name} className={`flex items-center justify-between p-3 rounded-lg border transition-all ${isBlocked ? 'bg-red-500/5 border-red-500/20' : 'bg-sentinel-800 border-sentinel-700 opacity-75 hover:opacity-100'}`}>
                                    <div className="flex flex-col">
                                        <span className={`text-sm font-mono font-medium ${isBlocked ? 'text-red-200' : 'text-slate-300'}`}>{sig.name}</span>
                                        <div className="flex items-center gap-1.5 mt-0.5">
                                          <Cpu className="w-3 h-3 text-slate-500" />
                                          <span className="text-[10px] text-slate-500 font-mono">{sig.process}</span>
                                        </div>
                                    </div>
                                    <button 
                                      onClick={() => toggleAppBlock(sig.name)}
                                      className={`px-3 py-1.5 rounded text-xs font-bold flex items-center gap-2 transition-colors ${
                                          isBlocked 
                                            ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30' 
                                            : 'bg-sentinel-700 text-slate-400 hover:bg-sentinel-600 hover:text-white'
                                      }`}
                                    >
                                      {isBlocked ? <><Ban className="w-3 h-3"/> BLOCKED</> : 'ALLOW'}
                                    </button>
                                </div>
                            )
                        })}
                    </div>
                  </div>

                  {/* Custom Rules Section */}
                  <div>
                    <h5 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                        <Lock className="w-3 h-3" /> Custom Process Rules
                    </h5>
                    {customBlockedApps.length === 0 ? (
                        <div className="text-center text-slate-600 text-sm italic py-2">No custom processes blocked.</div>
                    ) : (
                        <div className="space-y-2">
                            {customBlockedApps.map(app => (
                                <div key={app} className="flex items-center justify-between p-3 bg-sentinel-800 rounded-lg border border-sentinel-700 group hover:border-sentinel-600 transition-colors">
                                    <div className="flex items-center gap-3">
                                      <div className="p-1.5 bg-red-500/10 rounded-md">
                                        <Ban className="w-4 h-4 text-red-500" />
                                      </div>
                                      <span className="text-sm font-mono text-slate-200">{app}</span>
                                    </div>
                                    <button 
                                      onClick={() => toggleAppBlock(app)}
                                      className="p-1.5 hover:bg-sentinel-700 rounded text-slate-500 hover:text-red-400 transition-colors"
                                      title="Remove Rule"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </button>
                                </div>
                            ))}
                        </div>
                    )}
                  </div>
               </div>
            </div>
          )}

        </div>

        {/* Right Panel: Threat Log */}
        <div className="lg:col-span-1 bg-sentinel-900/30 rounded-xl border border-sentinel-700/50 p-0 flex flex-col h-full max-h-[350px] overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b border-sentinel-700/50 bg-sentinel-900/50">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-wider">
              <Terminal className="w-3 h-3 text-indigo-400" />
              Process Log
            </div>
            <div className="flex gap-2 text-[10px] text-slate-500 bg-sentinel-800 px-2 py-0.5 rounded-full border border-sentinel-700">
               <ShieldCheck className="w-3 h-3" />
               {blockedApps.size} Rules
            </div>
          </div>
          
          <div className="overflow-y-auto flex-1 p-2 space-y-1 custom-scrollbar bg-black/20 font-mono">
            {threatLogs.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-slate-600 space-y-3 opacity-50">
                <History className="w-8 h-8 mb-2" />
                <div className="text-xs italic text-center">No recent alerts.<br/>Traffic normal.</div>
              </div>
            ) : (
              threatLogs.map((log: ThreatLogEntry) => (
                <div key={log.id} className={`group flex flex-col p-2.5 rounded border-l-[3px] transition-all hover:bg-white/5 ${log.action === 'Blocked' ? 'border-l-red-500 bg-red-500/5' : 'border-l-emerald-500 bg-emerald-500/5'}`}>
                   <div className="flex justify-between items-center mb-1">
                     <span className="text-[10px] text-slate-500 flex items-center gap-1">
                       {log.time}
                     </span>
                     <span className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded-sm ${log.action === 'Blocked' ? 'bg-red-500/10 text-red-400' : 'bg-emerald-500/10 text-emerald-400'}`}>
                        {log.action}
                     </span>
                   </div>
                   <div className="flex items-center justify-between mt-1">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-slate-200 block truncate max-w-[120px]" title={log.threat}>{log.threat}</span>
                        </div>
                        <div className="flex items-center gap-1">
                           <Cpu className="w-3 h-3 text-slate-500" />
                           <span className="text-[10px] text-indigo-300 font-mono">{log.process}</span>
                        </div>
                      </div>
                      <button 
                        onClick={(e) => { e.stopPropagation(); toggleAppBlock(log.threat); }}
                        title={blockedApps.has(log.threat) ? "Unblock" : "Block"}
                        className={`opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-md ${blockedApps.has(log.threat) ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}
                      >
                         {blockedApps.has(log.threat) ? <Check className="w-3 h-3" /> : <Ban className="w-3 h-3" />}
                      </button>
                   </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};