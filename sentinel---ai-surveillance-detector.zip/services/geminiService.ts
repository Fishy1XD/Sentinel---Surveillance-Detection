// Local Offline Security Expert System
// No external API calls are made. All processing is done locally on the device.

export interface ChatSession {
  history: { role: string; parts: [{ text: string }] }[];
}

const KNOWLEDGE_BASE = [
  {
    keywords: ['camera', 'lens', 'reflection', 'mirror', 'hidden'],
    response: "## Physical Surveillance Detection\n\nTo detect hidden cameras:\n1. **Lens Reflection**: Turn off lights and shine a flashlight. Look for small, glinting reflections (blue/purple tint).\n2. **IR Sensors**: Use your phone's front camera (without IR filter) to scan for purple dots in the dark.\n3. **RF Detection**: Physical bugs often transmit via radio. A simple RF detector can find active transmissions."
  },
  {
    keywords: ['network', 'wifi', 'wi-fi', 'packet', 'traffic', 'slow'],
    response: "## Network Analysis\n\n1. **Unknown Devices**: Check your router's client list for unrecognized MAC addresses.\n2. **Data Spikes**: Large uploads when you aren't using the internet often indicate spyware or cloud backups.\n3. **DNS Auditing**: Change your DNS to a filtering provider (like Quad9 or NextDNS) to see blocked malicious requests."
  },
  {
    keywords: ['audio', 'microphone', 'listen', 'voice', 'recording'],
    response: "## Audio Surveillance\n\nAudio bugs are harder to visually detect. \n- **Power Draw**: Bugs need power. Check wall outlets and USB devices for tampering.\n- **Ultrasonic**: Some apps use ultrasonic beacons to track cross-device location. Revoke microphone permissions for apps that don't need it."
  },
  {
    keywords: ['process', 'task', 'manager', 'cpu', 'slow pc'],
    response: "## Process Auditing\n\n1. Open Task Manager (Ctrl+Shift+Esc).\n2. Look for processes with random names or generic names running from `AppData` or `Temp` folders.\n3. High CPU usage when idle often indicates crypto-miners or background processing/indexing by spyware."
  },
  {
    keywords: ['vpn', 'encrypt', 'tor', 'privacy'],
    response: "## Digital Hygiene\n\n- **VPN**: Encrypts traffic from your device to the exit node, hiding destination from your ISP.\n- **Tor**: Onion routing for high anonymity.\n- **HTTPS**: Ensure the 'Lock' icon is present on all sensitive websites."
  }
];

export const createSecurityAdvisorChat = (): ChatSession => {
  return {
    history: []
  };
};

export const sendMessageToAdvisor = async (chat: ChatSession, message: string): Promise<string> => {
  // Simulate "Thinking" time for realism
  await new Promise(resolve => setTimeout(resolve, 800));

  const lowerMsg = message.toLowerCase();
  
  // Local Heuristic Matching
  const match = KNOWLEDGE_BASE.find(entry => 
    entry.keywords.some(k => lowerMsg.includes(k))
  );

  if (match) {
    return match.response;
  }

  // Default Fallback
  return "I am operating in **Offline Mode**. \n\nI can assist with:\n- Physical Camera Detection\n- Network Traffic Analysis\n- Microphone/Audio Security\n- Digital Hygiene & VPNs\n\nPlease ask specifically about these topics.";
};